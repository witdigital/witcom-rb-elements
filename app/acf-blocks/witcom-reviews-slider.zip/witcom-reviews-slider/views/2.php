<?php

    /* ==========================================================================
        * Filename: render_template.php
        * Description: Front end for Review Grid Block
        * Author:  Ryan E. Mitchell

       [Table of contents]

        1. Includes and Dependencies
        2. Define Variables
            Get Wit Commander fields and set vars
        3. Get Posts
        4. Set instance specific vars
        5. Create Block Dynamic SCSS
        5. Compile SCSS
        7. Block Specific JS
        8. Render the Frontend
        ========================================================================== */


    /* ===========================  Includes and Dependencies  ========================== */

    use ScssPhp\ScssPhp\Compiler;


    /* ==========================================================================
        Define Variables
       ========================================================================== */

    if( !empty($block) ) {
        //    This instances ID
        $blockID   = $block['id'];
        $blockName = $block['name'];
        // replace forward slash in block name for better compatibility
        $blockName = str_replace('/', '_', $blockName);
    }

    // Create class attribute allowing for custom "className" and "align" values.
    $className = 'witcom-block ' . $blockName . ' ' . $blockID;
    if ( ! empty( $block['className'] ) ) {
        $className .= ' ' . $block['className'];
    }
    if ( ! empty( $block['align'] ) ) {
        $className .= ' align' . $block['align'];
    }

    /* ===  Get Wit Commander fields and set vars   ==== */

//        Breakpoints
//        todo convert to plugin level class
    if ( have_rows( 'witcom_breakpoints', 'option' ) ):
        while ( have_rows( 'witcom_breakpoints', 'option' ) ): the_row();

            $witcom_breakpoint_xs = get_sub_field( 'witcom_breakpoint_xs' );
            $witcom_breakpoint_sm = get_sub_field( 'witcom_breakpoint_sm' );
            $witcom_breakpoint_md = get_sub_field( 'witcom_breakpoint_md' );
            $witcom_breakpoint_lg = get_sub_field( 'witcom_breakpoint_lg' );
            $witcom_breakpoint_xl = get_sub_field( 'witcom_breakpoint_xl' );

        endwhile;
    endif;

    /* ===========================  Fonts  ========================== */

    if ( get_field( 'witcom_body_font', 'option' ) ) {
        $witcom_body_font = get_field( 'witcom_body_font', 'option' );
    } else {
        $witcom_body_font = 'Georgia, serif;';
    }

    if ( get_field( 'witcom_header_font', 'option' ) ) {
        $witcom_header_font = get_field( 'witcom_header_font', 'option' );
    } else {
        $witcom_header_font = 'Georgia, serif;';
    }

    /* ==========================================================================
       Get posts
       ========================================================================== */

    $args = array(
        'post_type'      => 'witcom_reviews',
        'post_status'    => 'publish',
        'posts_per_page' => - 1,
    );

    $post_query = new WP_Query( $args );

    if ( $post_query->have_posts() ):


        /* ===  Get post type options and set vars  ==== */



//        if ( get_field( 'witcom_reviews_star_image', 'option' ) ) {
//            $witcom_reviews_star_image = get_field( 'witcom_reviews_star_image', 'option' );
//        } else {
//            $witcom_reviews_star_image = '';
//        }
//
//
//        /* ===  Set instance specific vars ==== */
//
//        /* =========================== Layout ========================== */
//
//        if ( get_field( 'witcom_reviews_slider_padding' ) ) {
//            $witcom_reviews_slider_padding = get_field( 'witcom_reviews_slider_padding' );
//        } else {
//            $witcom_reviews_slider_padding = '0';
//        }
//
//        if ( get_field( 'witcom_reviews_slider_item_margins' ) ) {
//            $witcom_reviews_slider_item_margins = get_field( 'witcom_reviews_slider_item_margins' );
//        } else {
//            $witcom_reviews_slider_item_margins = '0';
//        }
//
//        if ( get_field( 'witcom_reviews_slider_grid_spacing' ) ) {
//            $witcom_reviews_slider_grid_spacing = get_field( 'witcom_reviews_slider_grid_spacing' );
//        } else {
//            $witcom_reviews_slider_grid_spacing = '0';
//        }
//
//        if ( get_field( 'witcom_reviews_slider_star_height' ) ) {
//            $witcom_reviews_slider_star_height = get_field( 'witcom_reviews_slider_star_height' );
//        } else {
//            $witcom_reviews_slider_star_height = '40';
//        }
//
//
//
//        if ( get_field( 'witcom_reviews_slider_star_height_mobile' ) ) {
//            $witcom_reviews_slider_star_height_mobile = get_field( 'witcom_reviews_slider_star_height_mobile' );
//        } else {
//            $witcom_reviews_slider_star_height_mobile = '40';
//        }
//
//        if ( get_field( 'witcom_reviews_slider_author_dash' ) ) {
//            $witcom_reviews_slider_author_dash = '-';
//        } else {
//            $witcom_reviews_slider_author_dash = '';
//        }
//
//
//        if ( get_field( 'witcom_reviews_grid_stars_color' ) ) {
//            $witcom_reviews_grid_stars_color = get_field( 'witcom_reviews_grid_stars_color' );
//        } else {
//            $witcom_reviews_grid_stars_color = '';
//        }
//
//
//
//
//
//
//
//        if ( get_field( 'witcom_reviews_slider_header_font_size' ) ) {
//            $witcom_reviews_slider_header_font_size = get_field( '$witcom_reviews_slider_header_font_size' );
//        } else {
//            $witcom_reviews_slider_header_font_size = '12';
//        }
//
//        /* ===========================  Colors  ========================== */
//
//        if ( get_field( 'witcom_reviews_slider_background_color' ) ) {
//            $witcom_reviews_slider_background_color = get_field( 'witcom_reviews_slider_background_color' );
//        } else {
//            $witcom_reviews_slider_background_color = '#ffffff';
//        }
//
//        if ( get_field( 'witcom_reviews_slider_header_color' ) ) {
//            $witcom_reviews_slider_header_color = get_field( 'witcom_reviews_slider_header_color' );
//        } else {
//            $witcom_reviews_slider_header_color = '#000000';
//        }
//
//        if ( get_field( 'witcom_reviews_slider_content_color' ) ) {
//            $witcom_reviews_slider_content_color = get_field( 'witcom_reviews_slider_content_color' );
//        } else {
//            $witcom_reviews_slider_content_color = '#000000';
//        }
//
//        if ( get_field( 'witcom_reviews_slider_author_color' ) ) {
//            $witcom_reviews_slider_author_color = get_field( 'witcom_reviews_slider_author_color' );
//        } else {
//            $witcom_reviews_slider_author_color = '#000000';
//        }
//
//
//
//
//
//        /* =========================== Font Sizes  ========================== */
//
//        if ( get_field( 'witcom_reviews_slider_header_font_size' ) ) {
//            $witcom_reviews_slider_header_font_size = get_field( 'witcom_reviews_slider_header_font_size' );
//        } else {
//            $witcom_reviews_slider_header_font_size = '42';
//        }
//
//        if ( get_field( 'witcom_reviews_slider_content_font_size' ) ) {
//            $witcom_reviews_slider_content_font_size = get_field( 'witcom_reviews_slider_content_font_size' );
//        } else {
//            $witcom_reviews_slider_content_font_size = '16';
//        }
//
//        if ( get_field( 'witcom_reviews_slider_author_font_size' ) ) {
//            $witcom_reviews_slider_author_font_size = get_field( 'witcom_reviews_slider_author_font_size' );
//        } else {
//            $witcom_reviews_slider_author_font_size = '16';
//        }
//
//
//
//
//
//
//        /* =========================== Additional SCSS   ========================== */
//
//        $witcom_button_radius = get_field( 'witcom_button_radius', 'option' );
//
//        if ( get_field( 'witcom_reviews_slider_additional_scss' ) ) {
//            $witcom_reviews_slider_additional_scss = get_field( 'witcom_reviews_slider_additional_scss' );
//        } else {
//            $witcom_reviews_slider_additional_scss = '';
//        }


        /* ==========================================================================
           Create Block Dynamic SCSS
           ========================================================================== */

        $witcom_reviews_slider_scss = /** @lang SCSS */
            "

            .$blockID {

              

            } /* End of .$blockID */

       ";  // end $witcom_split_content_scss

    ?>



    <?php


        /* ==========================================================================
           Compile SCSS
            todo evaluate if autoprefixer is needed.

           ========================================================================== */

        $scss = new Compiler();

        // Option to Crunch SCSS
        if ( get_field( 'crunch_witcom_scss', 'option' ) ):
            $scss->setFormatter( 'ScssPhp\ScssPhp\Formatter\Crunched' );
        else:
            $scss->setFormatter( 'ScssPhp\ScssPhp\Formatter\Expanded' );
        endif;




//        $compiledCssCode = $scss->compile( $witcom_reviews_slider_scss );
//
//        echo( "<style id='witcom-review-grid-$blockID'>\r\n" );
//        echo $compiledCssCode;
//        echo( '</style>' );


        /* ==========================================================================
           Render the Frontend
           ========================================================================== */
        ?>





        <div class="<?php echo esc_attr( $className ); ?>">

            <div class="inner-wrapper">
                <?php /* ===  hook  ==== */ witcom_reviews_slider_before_grid(); ?>
                <div class="reviews-slider glide">
                <div class="reviews glide__track" data-glide-el="track"">
                    <ul class="glide__slides">
                    <?php while ( $post_query->have_posts() ) : $post_query->the_post();

                        // Get the post ID for getting fields
                        $id = get_the_id();

                        // Get Post Fields and set vars
                        if ( get_field( 'witcom_review_headline', $id ) ) {
                            $witcom_review_headline = get_field( 'witcom_review_headline', $id );
                        } else {
                            $witcom_review_headline = '';
                        }

                        if ( get_field( 'witcom_review_stars', $id ) ) {
                            $witcom_review_stars = get_field( 'witcom_review_stars', $id );
                        } else {
                            $witcom_review_stars = '5';
                        }

                        if ( get_field( 'witcom_review_short_review', $id ) ) {
                            $witcom_review_short_review = get_field( 'witcom_review_short_review', $id );
                        } else {
                            $witcom_review_short_review = '';
                        }

                        if ( get_field( 'witcom_review_full_review', $id ) ) {
                            $witcom_review_full_review = get_field( 'witcom_review_full_review', $id );
                        } else {
                            $witcom_review_full_review = '';
                        }

                        if ( get_field( 'witcom_review_author', $id ) ) {
                            $witcom_review_author = get_field( 'witcom_review_author', $id );
                        } else {
                            $witcom_review_author = '';
                        }


                        ?>

                        <?php /* ===  hook  ==== */ witcom_reviews_slider_before_review(); ?>
                        <li class="review review-<?php echo $id; ?> glide__slide">
                            <div class="stars">

                                <?php

                                    $starCount = 1;

                                    while($starCount <= $witcom_review_stars) { ?>
<!--                                        <img src=' --><?php //echo $witcom_reviews_star_image['url']; ?><!--' class='star'/>-->

                                       <?
                                        $starCount++;
                                    }
                                    ?>

                            </div>


                            <div class="heading">
                                <h3><?php echo $witcom_review_headline; ?></h3>
                            </div>

                            <div class="content">
                                <?php echo  $witcom_review_full_review; ?>
                            </div>



                            <div class="author">
                                <?php echo  $witcom_review_author; ?>
                            </div>


                            <?php /* ===  hook  ==== */ witcom_reviews_slider_inside_review(); ?>

                        </li>
                        <?php /* ===  hook  ==== */ witcom_reviews_slider_after_review(); ?>

                        <?php


                        the_excerpt();
                    endwhile; ?>

                    </ul>

                    <?php

                        wp_reset_postdata(); ?>
                </div>

                <div data-glide-el="controls">
                    <button data-glide-dir="<<">Start</button>
                    <button data-glide-dir=">>">End</button>
                </div>
                </div>
            </div>
            <?php /* ===  hook  ==== */ witcom_reviews_slider_after_grid(); ?>
        </div>
    <?php
    endif;

   /* ==========================================================================
      Block Specific JS
      ========================================================================== */
?>
             <!--
                <script>
                    document.addEventListener("DOMContentLoaded", function() {
                        window.alert('witcom-reviews plugin acf-block')
                    });
                </script>
                -->
<script type="text/javascript">


    document.addEventListener("DOMContentLoaded", function(){
        new Glide('.reviews-slider.glide', {
            type: 'carousel',
            startAt: 0,
            perView: 3
        })

    });


</script>
