
<?php


    // args
    $args = array(
        'posts_per_page' => 3,
        'post_type'      => 'witcom_reviews',
        'orderby'        => 'date',
        'order'          => 'DESC',
    );
    // get results
    $the_query = new WP_Query($args);

    // The Loop - Testimonials Loop
    if ($the_query->have_posts()) : ?>
        <!--        --><?php //$id = generateRandomString(); ?>
        <?php $id = 'random'; ?>
        <?php $slider_id = $id.'_testimonials-mini-orbit'; ?>
        <div class="<?php echo $id ?> testing">

        <div class="glide">

            <div class="<?php echo $slider_id ?> glide__track" data-glide-el="track">

                <div class="glide__slides">
                    <?php while ($the_query->have_posts()) :
                        $the_query->the_post();

                        // vars
                        $review_headline        = get_field('witcom_review_headline', get_the_ID());
                        $review_stars           = get_field('witcom_review_stars', get_the_ID());
                        $review_short_review    = get_field('witcom_review_short_review', get_the_ID());
                        $review_full_review     = get_field('witcom_review_full_review', get_the_ID());
                        $review_author          = get_field('witcom_review_author', get_the_ID());

                        ?>

                        <div class="glide__slide">

                            <div class="testimonial-content">


                                <?php if ($review_headline ) : ?>
                                    <div class="review-headlines">
                                        <p><?php echo $review_headline; ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if ($review_short_review ) : ?>
                                    <div class="review-short-reviews">
                                        <p><?php echo $review_short_review; ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if ($review_author ) : ?>
                                    <div class="review-authors">
                                        <p><?php echo $review_author; ?></p>
                                    </div>
                                <?php endif; ?>



                            </div>

                        </div>

                    <?php endwhile; ?>
                </div>



            </div>


            <div class="glide__bullets" data-glide-el="controls[nav]">
                <button class="glide__bullet" data-glide-dir="=0"></button>
                <button class="glide__bullet" data-glide-dir="=1"></button>
                <button class="glide__bullet" data-glide-dir="=2"></button>
            </div>

            <div data-glide-el="controls">
                <button data-glide-dir="<<">Start</button>
                <button data-glide-dir=">>">End</button>
            </div>


        </div>



    <?php endif; // End Loop--> ?>
    <?php wp_reset_query(); ?>


    <style>

        .testing {
            display: block;
            border: 1px dashed blueviolet;
        }

        .glide__slide {

            list-style: none;
            background-color: darkblue;
            color: #fff;
            min-height: 400px;



        }

        .testimonial-content {
            min-height: 400px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }


    </style>

    <script type="text/javascript">


        document.addEventListener("DOMContentLoaded", function(){



            new Glide('.glide', {
                type: 'carousel',
                startAt: 0,
                perView: 3
            }).mount({  })

        });


    </script>


